
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>

<?php $__env->startSection('content'); ?>
<div class="container">
            <h1 class="mt-2">Detail Umat</h1>
                <div class="row">
                    <div class="col-6">
                        <div class="card border-danger">
                            <div class="card-body">
                                <h5 class="card-title">Informasi Pribadi</h5>
                                 <?php $__currentLoopData = $umat_nama; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <li class="list-group">Nama Lengkap: <?php echo e($dup->umat_nama); ?></li>
                                         <li class="list-group">NIK: <?php echo e($dup->umat_ktp); ?></li>
                                         <li class="list-group">Nomor KK: <?php echo e($dup->umat_kk); ?></li>
                                         <li class="list-group">Tempat Tanggal Lahir: <?php echo e($dup->umat_tempat_lahir); ?>, <?php echo e($dup->umat_tanggal_lahir); ?></li>
                                         <li class="list-group">Status Nikah: <?php echo e($dup->status_nikah_nama); ?></li>
                                         <li class="list-group">Hubungan Keluarga <?php echo e($dup->hubungan_keluarga_nama); ?></li>
                                         <li class="list-group">Status Rumah: <?php echo e($dup->status_rumah_nama); ?></li>
                                         <li class="list-group">Pendidikan: <?php echo e($dup->pendidikan_nama); ?></li>
                                         <li class="list-group">Golongan Darah: <?php echo e($dup->golongan_darah_nama); ?></li>
                                         <?php if($dup->umat_jenis_kelamin === 1): ?>
                                            <li class="list-group">Jenis Kelamin: Perempuan</li>
                                         <?php else: ?>
                                            <li class="list-group">Jenis Kelamin: Laki-Laki</li>
                                         <?php endif; ?>
                                         <li class="list-group">Alamat: <?php echo e($dup->umat_alamat); ?></li>
                                         <li class="list-group">Kabupaten/Kota: <?php echo e($dup->umat_kota_kab); ?></li>
                                         <li class="list-group">Kecamatan: <?php echo e($dup->umat_kecamatan); ?></li>
                                         <li class="list-group">Kelurahan: <?php echo e($dup->umat_kelurahan); ?></li>
                                         <li class="list-group">Nomor Telepon: <?php echo e($dup->umat_handphone); ?></li>
                                         <li class="list-group">Email: <?php echo e($dup->umat_email); ?></li>
                                         <li class="list-group">Jurusan: <?php echo e($dup->umat_jurusan); ?></li>
                                         <li class="list-group">Profesi: <?php echo e($dup->profesi_nama); ?></li>
                                         <li class="list-group">Pekerjaan: <?php echo e($dup->pekerjaan_nama); ?></li>
                                         <li class="list-group">Keterampilan: <?php echo e($dup->umat_keterampilan); ?></li>
                                         <li class="list-group">Status Aktivitas Sosial: <?php echo e($dup->status_aktivitas_sosial_nama); ?></li>
                                         <li class="list-group">Disabilitas: <?php echo e($dup->tuna_nama); ?></li>
                                         <li class="list-group">Penghasilan: <?php echo e($dup->penghasilan); ?></li>
                                         <li class="list-group">Narasi: <?php echo e($dup->narasi); ?></li>       
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="card border-danger">
                            <div class="card-body">
                                <h5 class="card-title">Informasi Gerejawi</h5>
                                 <?php $__currentLoopData = $umat_nama; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <li class="list-group">Nama Baptis: <?php echo e($dup->umat_nama_baptis); ?></li>
                                         <li class="list-group">Nomor Buku Baptis: <?php echo e($dup->umat_buku_baptis); ?></li>
                                         <li class="list-group">Nomor Baptis: <?php echo e($dup->umat_nomer_baptis); ?></li>
                                         <li class="list-group">Keuskupan Baptis: <?php echo e($dup->keuskupan_nama); ?></li>
                                         <li class="list-group">Paroki Baptis: <?php echo e($dup->paroki_nama); ?></li>
                                         <li class="list-group">Suku: <?php echo e($dup->suku_nama); ?></li>
                                         <li class="list-group">Status Ekonomi: <?php echo e($dup->status_ekonomi_nama); ?></li>
                                         <li class="list-group">Agama: <?php echo e($dup->agama_nama); ?></li>
                                         <li class="list-group">Kevikepan: <?php echo e($dup->kevikepan_nama); ?></li>
                                         <li class="list-group">Paroki: <?php echo e($dup->paroki_nama); ?></li>
                                         <li class="list-group">Wilayah: <?php echo e($dup->wilayah_nama); ?></li>
                                         <li class="list-group">Lingkungan: <?php echo e($dup->lingkungan_nama); ?></li>
                                         <?php if($dup->umat_meninggal === 1): ?>
                                            <li class="list-group">Status Meninggal: Meninggal</li>
                                         <?php else: ?>
                                            <li class="list-group">Status Meninggal: Belum Meninggal</li>
                                         <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                <div class="col-6 mb-3">
                <div class="card border-light"></div>
                <div class="card border-light"></div>
                <div class="card border-light"></div>
                <div class="card border-light"></div>
                <div class="card border-light"></div>
                <div class="card border-light"></div>
                    <div class="card border-danger">
                        <div class="card-body">
                            <h5 class="card-title">Berkas Bukti</h5>
                            <li class="list-group">Tanggal Update: <?php echo e($dup->tgl_update); ?></li>
                            <a href=""  name="Upload" id=""><button type="button" class="btn btn-danger">Upload</button></a>
                            <a href=""  name="Upload" id=""><button type="button" class="btn btn-danger">Upload</button></a>
                            <a href=""  name="Upload" id=""><button  type="button" class="btn btn-danger">Upload</button></a>
                        </div>
                    </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\KP_Laravel\resources\views/detailUmat.blade.php ENDPATH**/ ?>
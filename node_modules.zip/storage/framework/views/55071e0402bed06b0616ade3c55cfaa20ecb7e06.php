
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-10">
            <h1 class="mt-2">Daftar Umat</h1>
            <label for="name" class=" col-form-label"><b>Lingkungan</b></label>
            
            <div id="container-table table-responsive">
                <table class="table">
                    <div class="row">
                        <div class="col-sm-9">
                            <div class="form-group row">
                                <div class="col-sm-9">
                                    <select name="Lingkungan" id="Lingkungan" class="form-control input-lg" required>
                                        <option value="0">== Pilih Lingkungan ==</option>
                                        <?php $__currentLoopData = $dataLingkungan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($dl->lingkungan_id); ?>"><?php echo e($dl->lingkungan_nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-sm-3">
                                    <a href="dataUmat/PDF/0" target="_blank" name="Export" id="Export"><button type="button" class="btn btn-primary">Export to PDF</button></a>
                                </div>
                            </div>
                        </div>
                        <div  class="col-sm-3">
                            <nav aria-label="Page navigation example">
                                <?php echo e($dataUmat->links()); ?>

                            </nav>
                        </div>
                    </div>
                    <thead class="thead-dark">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Nomor KK</th>
                            <th scope="col">Nama Umat</th>
                            <th scope="col">Hubungan Keluarga</th>
                            <th scope="col">Buku Baptis</th>
                            <th scope="col">Agama</th>
                            <th scope="col">Nomor Handphone</th>
                            <th scope="col">Narasi</th>
                            <th scope="col">Status Meninggal</th>
                        </tr>
                    </thead>
                    <tbody id="daftarUmatLingkungan">
                        <?php $__currentLoopData = $dataUmat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $du): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td scope="row"><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($du->umat_kk); ?></td>
                                <td><?php echo e($du->umat_nama); ?></td>
                                <td><?php echo e($du->hubungan_keluarga_nama); ?></td>
                                <td><?php echo e($du->umat_buku_baptis); ?></td>
                                <td><?php echo e($du->agama_nama); ?></td>
                                <td><?php echo e($du->umat_handphone); ?></td>
                                <td><?php echo e($du->narasi); ?></td>
                                <?php if($du->umat_meninggal === 1): ?>
                                    <td>Meninggal</td>
                                <?php else: ?>
                                    <td>-</td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function(){
        $('select[name=Lingkungan]').on('change', function(){
            var LingkunganID = $(this).val();
            document.getElementById('Export').setAttribute("href", "dataUmat/PDF/"+LingkunganID);
            $.ajax({
                url: '/dataUmat/'+LingkunganID,
                type: "GET",
                dataType: "json",
                success:function(data){
                    var i = 1;
                    $('#daftarUmatLingkungan').empty();
                    $.each(data, function(key, value){
                        var meninggal = "";
                        if(value.umat_meninggal == 1){
                            var meninggal = "Meninggal"
                        }else{
                            var meninggal = "-"
                        }
                        $('#daftarUmatLingkungan').append("<tr><td scope='row'>"+i+
                            "</td><td>"+value.umat_kk+
                            "</td><td>"+value.umat_nama+
                            "</td><td>"+value.hubungan_keluarga_nama+
                            "</td><td>"+value.umat_buku_baptis+
                            "</td><td>"+value.agama_nama+
                            "</td><td>"+value.umat_handphone+
                            "</td><td>"+value.narasi+
                            "</td><td>"+meninggal+"</td></tr>");
                            
                            i++;
                    });
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\KP_Laravel\resources\views/index.blade.php ENDPATH**/ ?>